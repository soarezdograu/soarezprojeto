// Selecionar o ícone do carrinho e o painel do carrinho
const cartIcon = document.getElementById('cart-icon');
const cartPanel = document.getElementById('cart-panel');
const closeBtn = document.querySelector('.close-btn');

// Abrir o painel do carrinho quando o ícone for clicado
cartIcon.addEventListener('click', function(event) {
    event.preventDefault(); // Evitar a navegação padrão do link
    cartPanel.style.display = 'block'; // Mostrar o painel
});

// Fechar o painel do carrinho quando o botão de fechar for clicado
closeBtn.addEventListener('click', function() {
    cartPanel.style.display = 'none'; // Esconder o painel
});
