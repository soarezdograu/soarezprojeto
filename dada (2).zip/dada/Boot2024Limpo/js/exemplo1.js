//função mensagem
alert("\nMensagem externa");

//Escrever no HTML
document.write("<h2>Sarah</h2>");

//variáveis
var x = 4;
var texto = "Sarah";

//Estruturas de seleção
if( x >= 10)
{
    document.write("<br> X = 10");
}
else{
    document.write("<br> X ,10");
}

if(x > 6) {
    document.write("<br> 6");
}
else if( x == 4){
    document.write("<br> 0");
}
//OPERADORES RELACIONAIS
//>= maior ou igual
//<= menor ou igual
//== igual
//!= diferente
// == igualdade

