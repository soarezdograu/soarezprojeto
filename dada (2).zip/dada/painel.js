// Função para alternar a visibilidade do painel de menu
function toggleMenu() {
    const menuPanel = document.getElementById("menu-panel");
    menuPanel.style.display = (menuPanel.style.display === "block") ? "none" : "block";
}

// Evento de clique no ícone das três barrinhas
document.getElementById("bar-icon").addEventListener("click", function(event) {
    event.preventDefault();
    toggleMenu();
});

// Fechar o menu ao clicar fora dele
window.addEventListener("click", function(event) {
    const menuPanel = document.getElementById("menu-panel");
    const barIcon = document.getElementById("bar-icon");
    
    if (menuPanel.style.display === "block" && !menuPanel.contains(event.target) && !barIcon.contains(event.target)) {
        menuPanel.style.display = "none";
    }
});
