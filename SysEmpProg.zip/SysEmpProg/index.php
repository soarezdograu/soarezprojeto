<?php
    //redirecionamento em PHP
    header('Location: ./view/emprego/inicio.php');
?>