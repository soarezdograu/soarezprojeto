<?php
        include_once("header.php");
        include_once("../../model/Conexao.class.php");
        include_once("../../model/Entity.class.php");
        $empEntity = new Entity();
        $id = $_POST["id"];
?>
<div class="container espacoTop"><!-- Corpo do sistema -->

    <h2 class="text-center">Alterar brinquedo</h2>

    <form method="post" action="../../controller/emprego/update.php">
        <div class="container">
            <class="form">
                  <?php  foreach($empEntity->getInfo("emprego",$id) as $emp)      { ?>

                    <input type="hidden" name="id" value="<?=$emp['id']?>"/>

                    <div class="form-group">
                        <label>Título:</label>
                        <input type="text" 
                        class="form-control" 
                        placeholder="Título" 
                        name="titulo" 
                        value="<?=$emp['titulo']?>"
                        required autofocus/>
                    </div>
                    <div class="form-group">
                        <label>Descrição:</label>
                        <input type="text" 
                        class="form-control" 
                        placeholder="Descrição" 
                        name="descricao" 
                        value="<?=$emp['descricao']?>"
                        required/>
                    </div>
                    <div class="form-group">
                        <label>Ativo:</label>
                    <div class="radio-item">   
                        <input type="radio" 
                        id="ativoA" 
                        name="ativo" 
                        value="s" 
                        <?php if($emp['ativo']=='s'){ echo 'checked';}  ?>
                        checked>
                        <label>Sim</label>
                    </div>
                    <div class="radio-item">
                        <input type="radio" 
                        id="ativoB" 
                        name="ativo" 
                        value="n">
                        <?php if($emp['ativo']=='n'){ echo 'checked';}  ?>
                        <label>Não</label>
                    </div>
                    </div>
                    <div class="form-group">
                        <label>Data:</label>
                        <input type="date" 
                        class="form-control" 
                        placeholder="Data" 
                        name="data" 
                        style="width:40% ;"
                        value='<?php 
                            $date = date_create($emp['data']);
                            echo date_format($date,'Y-m-d');
                        ?>' 
                        required />
                    </div>

                    <?php } ?>

                    <div class="form-group">
                        <button class="btn btn-outline-primary btn-lg">
                        <i class='fas fa-cloud-upload-alt' style='font-size:24px'></i> Inserir</button>
                        <a href="listagem.php" class="btn btn-outline-primary btn-lg">
                        <i class='fas fa-reply-all' style='font-size:24px'></i> Voltar</a>
                    </div>
            </div>
        </div>
    </form>

</div>
<?php
        include_once("footer.php");
?>