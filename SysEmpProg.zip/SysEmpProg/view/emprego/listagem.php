<?php
        session_start();
        include_once("header.php");
        include_once("../../model/Conexao.class.php");
        include_once("../../model/Entity.class.php");
        $empEntity = new Entity();
?>
<DIV class="container espacoTop"><!-- Corpo do sistema -->

<H2>Empregodawdawdada</H2>

<div class="text-right">
    <a href="page_register.php" class="btn btn-outline-primary">
    <i class='fas fa-file-alt' style='font-size:24px'></i>
        Cadastrar
    </a>
</div>
<br>
<?php
if(isset($_SESSION["msg"])){
echo "<div id='alerta' class='alert alert-success'>"
. $_SESSION["msg"] ."</div>";
unset($_SESSION["msg"]);
}
if(isset($_SESSION["msg_error"])){
    echo "<div id='alerta' class='alert alert-danger'>"
    . $_SESSION["msg_error"] ."</div>";
    unset($_SESSION["msg_error"]);
}
?>



<div class="table-responsive">
    <table id="idTable" class="table mt-3 table-striped table-berdered">
        <thead>
            <tr>
                <th>ID</th>
                <th>TITULO</th>
                <th>DESCRIÇÃO</th>
                <th>STATUS</th>
                <th>DATA</th>
                <th>AÇÕES</th>
            </tr>
        </thead>
        <tbody>
            <?PHP foreach($empEntity->list("emprego") as $emp) { ?>
                <tr>
                    <td> <?php echo $emp["id"]; ?></td>
                    <td> <?php echo $emp["titulo"]; ?></td>
                    <td> <?php echo $emp["descricao"]; ?></td>
                    <td> <?php echo $emp["ativo"]; ?></td>
                    <td> <?php echo date("d/m/Y", strtotime($emp["data"])); ?></td>
                    <td>
                        <div class="row">
                            <div class="col-sm 6">
                                <form action="page_update.php" method="post">
                                    <input type="hidden" name="id" value=" <?=$emp['id']?>"/>
                                    <button title="Alterar" class="btn btn-outline-primary btn-xs">
                                        <i class='fas fa-edit' style='font-size:24px'></i>
                                    </button>
                                </form>
                            </div>
                            <div class="col-sm 6">
                            <form method="post" action="../../controller/emprego/delete.php">
                                <input type="hidden" name="id" value=" <?=$emp['id']?>"/>
                                <button title="Deletar" class="btn btn-outline-primary btn-xs">
                                <i class='fas fa-trash-alt' style='font-size:24px'></i>
                                </button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>

            <?php } ?>
        </tbody>
    </table>

</div>

</div>
<?php
        include_once("footer.php");
?>
<script>
    $(document).ready(function(){
        setTimeout(function(){
            $("alerta").hide("slow");
        },3000);
    });
</script>