<?php
        include_once("header.php");
?>
<div class="container espacoTop"><!-- Corpo do sistema -->

    <h2 class="text-center">Cadastro ddadadadae Emprego</h2>

    <form method="post" action="../../controller/emprego/insert.php">
        <div class="container">
            <div class="form">
                    <div class="form-group">
                        <label>Título:</label>
                        <input type="text" class="form-control" placeholder="Título" name="titulo" required autofocus/>
                    </div>
                    <div class="form-group">
                        <label>Descrição:</label>
                        <input type="text" class="form-control" placeholder="Descrição" name="descricao" required/>
                    </div>
                    <div class="form-group">
                        <label>Ativo:</label>
                        <div class="radio-item">
                            <input type="radio" id="ativoA" name="ativo" value="s" checked>
                            <label>Sim</label>
                        </div>
                        <div class="radio-item">
                            <input type="radio" id="ativoB" name="ativo" value="n">
                            <label>Não</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Data:</label>
                        <input type="date" class="form-control" placeholder="Data" name="data" style="width:40% ;" required />
                    </div>
                    <div class="form-group">
                        <button class="btn btn-outline-primary btn-lg">
                        <i class='fas fa-cloud-upload-alt' style='font-size:24px'></i> Inserir</button>
                        <a href="listagem.php" class="btn btn-outline-primary btn-lg">
                        <i class='fas fa-reply-all' style='font-size:24px'></i> Voltar</a>
                    </div>
            </div>
        </div>
    </form>

</div>
<?php
        include_once("footer.php");
?>