<?php
        include_once("header.php");
        include_once("../../model/Conexao.class.php");
        include_once("../../model/Entity.class.php");
        $empEntity = new Entity();
?>
<div class="container"><!-- Corpo do sistema -->

<?php
    echo "<br><br>";
    foreach($empEntity->list("emprego") as $emp){
        echo "<br>".$emp["titulo"]." - ".$emp["descricao"];
    }

?>

</div>
<?php
        include_once("footer.php");
?>