<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="shortcut icon" href="../../assets/img/icone.png" type="image/png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css" />

    <!-- Fontawesome 5 -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

    <!-- GoogleFonts - OpenSans -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

    <!-- CSS Personalizado-->
    <link rel="stylesheet" href="../../assets/css/master.css" />

  <!-- Javascript -->
    <script src="../../assets/js/jquery-3.5.1.js"></script>   
   <script src="../../assets/js/bootstrap.min.js"></script> 
  

    <title>Exemplos Coman131231dos PHP</title>
  </head>
  <body class="bg-dark">

    <div class="container"> <!-- Esse container fecha na página footer.php>
 Navbar -->

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-vaga-nav" >
      <a class="navbar-brand" href="#">Menu</a>
      
      <button class="navbar-toggler" type="button" data-toggle="collapse"
       data-target="#menu" aria-controls="menu" aria-expanded="false"
        aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
          <a class="nav-link" href="#" >Home</a>
          </li>       

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01"
             data-toggle="dropdown" >Exemplos</a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="exemplo1.php">Exemplo 1</a>
              <a class="dropdown-item" href="exemplo2.php">Exemplo 2</a>
              <a class="dropdown-item" href="exemplo3.php">Exemplo 3</a>
              <a class="dropdown-item" href="exemplo4.php">Exemplo 4</a>
              <a class="dropdown-item" href="exemplo5.php">Exemplo 5</a>
              <a class="dropdown-item" href="exemplo6.php">Exemplo 6</a>
              <a class="dropdown-item" href="exemplo7.php">Exemplo 7</a>
              <a class="dropdown-item" href="exemplo8.php">Exemplo 8</a>
              <a class="dropdown-item" href="exemplo9.php">Exemplo 9</a>

            </div>
          </li>          
        </ul>      
      </div>
    </nav>
    <div class="jumbotron">
        <h1 class="d-flex justify-content-end">Sistema de CRUD OO em MVC</h1>
        <p class="d-flex justify-content-end">Exemplo de CRUD com PHP orientados a objetos</p>
      </div>


