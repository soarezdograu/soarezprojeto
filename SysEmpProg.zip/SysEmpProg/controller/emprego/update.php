<?php
session_start();
include_once '../../model/Conexao.class.php';
include_once '../../model/Entity.class.php';

$Entity = new Entity(); //classe responsavel por modelar o banco
$id = $_POST["id"];
$dados = $_POST;

    if(isset($id) && !empty($id)){
        //chamar o insert do banco

        $Entity->update("emprego",$dados, $id);

        header('Location: ../../view/emprego/listagem.php');
    }
?>