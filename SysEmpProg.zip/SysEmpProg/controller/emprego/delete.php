<?php
session_start();
include_once '../../model/Conexao.class.php';
include_once '../../model/Entity.class.php';

$Entity = new Entity(); //classe responsavel por modelar o banco
$id = $_POST["id"];

    if(isset($id) && !empty($id)){
        //chamar o delete do banco
        try{
            $Entity->delete("emprego", $id);
            $_SESSION["msg"] = "Deletado com Sucesso.";
        }catch(Exception $e){
            $_SESSION["msg_error"] = "$e";
        }
        header('Location: ../../view/emprego/listagem.php');
    }

?>