<?php
session_start();
include_once '../../model/Conexao.class.php';
include_once '../../model/Entity.class.php';

$Entity = new Entity(); //classe responsavel por modelar o banco
$dados = $_POST;

    if(isset($dados) && !empty($dados)){
        //chamar o insert do banco

        $Entity->insert("emprego", $dados);

        header('Location: ../../view/emprego/listagem.php');
    }

?>