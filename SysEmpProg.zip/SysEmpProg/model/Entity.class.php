<?php 

    class Entity extends Conexao{
    
        public function list($table){

            //conexao
            $pdo = parent::getInstance();

            //minha consulta sql
            $sql = "SELECT * FROM $table order by id ASC";

            $statement = $pdo->query($sql);
            $statement->execute();

            return $statement->fetchAll();
        }

        public function insert($table, $dados){

            $pdo = parent::getInstance();
            $campos = implode(", ", array_keys($dados));
            $valores = ":".implode(", :", array_keys($dados));

            $sql = "INSERT INTO $table($campos) VALUES ($valores)";

            //echo "$sql";

            $statement = $pdo->prepare($sql);
            
            foreach ($dados as $key => $value) {
                $statement->bindValue(":$key", $value, PDO::PARAM_STR);

        }
        $statement->execute(); //OQ EXECUTA O SQL NO BANCO
    }

    public function delete($table, $id){
        $pdo = parent::getInstance();
        $sql = "DELETE FROM $table WHERE id = :id";
        $statement = $pdo->prepare($sql);
        $statement->bindValue("id", $id);
        $statement->execute();
        }  

        public function getInfo($table, $id)
        {
            $pdo = parent::getInstance();
            $sql = "SELECT * FROM $table WHERE id = :id";
            $statement = $pdo->prepare($sql);
            $statement->bindValue("id", $id);
            $statement->execute();
            return $statement->fetchAll(); //retorna em formato de array
            } 
        public function update($table, $dados , $id){

            $pdo = parent::getInstance();
            $novos_valores = " ";
            foreach ($dados as $key => $value) {
                $novos_valores .= "$key=:$key, ";
        }
        $novos_valores = substr($novos_valores, 0,-2);
        $sql = "UPDATE $table SET $novos_valores WHERE id= :id";
        $statement = $pdo->prepare($sql);

        foreach ($dados as $key => $value) {
         $statement->bindValue(":$key", $value, PDO::PARAM_STR);
    }

    $statement->bindValue("id", $id);
    $statement->execute();
      }
    }
?>
