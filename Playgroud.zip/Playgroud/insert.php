<?php
include_once("conexao.php");
include_once("entity.php");


$Entity = new Entity();
$dados= $_POST;

if(isset($dados) && !empty($dados)){
    //chamar o insert do banco

    $Entity->insert("login", $dados);

    header('location: login.php');

}

?>