<?php
session_start();
include_once("conexao.php");
include_once("entity.php");


$Entity = new Entity();
$usuario= $_POST["usuario"];
$senha= $_POST["senha"];

if(isset($senha) && !empty($senha)){
    //chamar o insert do banco

    try{
        $login = $Entity->login("login", $usuario, $senha);
        if(count($login)>0)
            {
                $_SESSION['msq'] = "$usuario";
                header('location: index.php');
            }
            else{
                $_SESSION['msq'] = "Erro";
                header('location: login.php');
            }
            echo  $_SESSION['msq'];
        }catch(Exception $e)
        {
            $_SESSION['msq'] = "Erro $e";
            echo $e;
            header('location: login.php');
        }

}

?>