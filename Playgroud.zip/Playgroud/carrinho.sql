CREATE DATABASE Carrinhoplaygroud;
USE Carrinhoplaygroud;
-- --------------------------------------------------------

--
-- Tabela de produtos
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `nome` VARCHAR(255) NOT NULL,
    `descricao` TEXT,
    `preco` DECIMAL(10, 2) NOT NULL,
    `estoque`  INT DEFAULT 0,
    `categoria_id`  INT,
    `imagem_url` VARCHAR(255)
);

--Tabela do Carrinho de Compras--

DROP TABLE IF EXISTS `carrinho`;
CREATE TABLE IF NOT EXISTS `carrinho` (
    `id`INT PRIMARY KEY AUTO_INCREMENT,
    `usuario_id` INT NOT NULL,
    `data_adicao` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`)
);

--ITENS DO CARRINHO TABELA--

 DROP TABLE IF EXISTS `itens_carrinho`;
CREATE TABLE IF NOT EXISTS `itens_carrinho`(
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `carrinho_id` INT NOT NULL,
    `produto_id` INT NOT NULL,
    `quantidade` INT NOT NULL,
    `preco_unitario` DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (`carrinho_id`) REFERENCES `carrinho`(`id`),
    FOREIGN KEY (`produto_id`) REFERENCES `produtos`(`id`)
);