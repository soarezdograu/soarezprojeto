<?php
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Playground</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> <link href="https://fonts.googleapis.com/css2?family=Atma:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, max-scale=1.0"> 
<body>

    <!-- Header -->
    <header>
        <nav>
            <div class="logo">
                <h1>PLAY<span>GROUND</span></h1>
            </div>
            <ul class="menu">
                <li><a href="index.html">Home</a></li>
                <li><a href="pag.html">Loja</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
            <div class="icons">
                <!-- Ícone do carrinho de compras -->
                <a href="#" id="cart-icon" title="Carrinho de compras">
                    <img src="https://cdn-icons-png.flaticon.com/512/1170/1170576.png" alt="Carrinho de compras" width="40" height="40">
                </a>
                
                <!-- Ícone das três barrinhas -->
                <a href="#" id="bar-icon" title="Menu">
                    <img class="bar" src="img/cardapio.png" alt="Menu" width="40" height="40">
                </a>
            </div>
            <!-- Menu que aparece ao clicar nas três barrinhas -->
            <div id="menu-panel" class="menu-panel">
                <a href="logout.php" id="logout">Sair da Conta</a>
            </div>
            
        </nav>
    </header>

    <!-- Main Banner -->
    <section class="banner">
        <div class="slider">
            <div class="slide">
                
            </div>
        </div>
        <div class="banner-text">
            <a href="pag.html" class="atma-bold">VEJA</a>
        </div>
    </section>


    <section class="about">
        <div class="about-box">
           
           
        </div>
        
    </section>

    <!-- Info Section -->
    <section class="info-section">
        <div class="info-card">
            <img src="img/piscina.jpg" alt="Imagem info 1">
            <h3>Piscina de bolinhas</h3>
            <a href="pag.html" class="btn-secondary">Ver mais</a>
        </div>
        <div class="info-card">
            <img src="img/castelo.jpg" alt="Imagem info 2">
            <h3>Produto 2</h3>
            <a href="pag.html" class="btn-secondary">Ver mais</a>
        </div>
        <div class="info-card">
            <img src="img/OIP.jpg" alt="Imagem info 3">
            <h3>Produto 3</h3>
            <a href="pag.html" class="btn-secondary">Ver mais</a>
        </div>
    </section>
    <section class="parametro">
        <div class="parabox-box">
           
           
        </div>
        
    </section>
    
    

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Playground. Todos os direitos reservados.</p>
    </footer>

     <!-- Painel de carrinho de compras (Oculto por padrão) -->
     <div id="cart-panel" class="cart-panel">
        <div class="cart-header">
            <span class="close-btn">&times;</span>
            <h2 class="carrinho">Carrinho</h2>
        </div>
        <div class="cart-body">
            <p>O carrinho está vazio</p>
        </div>
    </div>
<!-- Link para o script.js -->
    <script src="script.js"></script>
    <script src="painel.js"></script>

</body>
</html>
