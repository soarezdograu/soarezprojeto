
<button?php
session_start();
?>
<!DOCTYPE html>
<html>
    
<head>
	<title>LOGIN</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">

	<link href="./assets/css/master.css" rel="stylesheet">


</head>


<!--Coded with love by Mutiullah Samim-->
<body>
	<div class="container h-100">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="./imagens/logoplay.png" class="brand_logo" alt="Logo"/>
					</div>
				</div>
				<div class="d-flex justify-content-center form_container">
					<form action="logar.php" method="post">
						<div class="input-group mb-3">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" name="usuario" class="form-control input_user" value="" placeholder="usuario" required>
						</div>
						<div class="input-group mb-2">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" name="senha" class="form-control input_pass" value="" placeholder="senha" required>
						</div>
						<div class="form-group">
						</div>
							<div class="d-flex justify-content-center mt-3 login_container">
				 	<button class="btn login_btn">Entrar</button>
				   </div>
					</form>
				</div>
				<div class="mt-4">
					<div class="d-flex justify-content-center links">
						<p>Não possui conta? </p>
						<a href="cadastro.php" class="btn cadastro_btn ml-2" >Cadastre-se</a>
					</div>
				</div>
				<div class="mt-4">
					<div class="d-flex justify-content-center  links">
						<p>Esqueceu senha?</p>
						<a href="recuperar.php" class="btn recupere_btn ml-2" >Recupere aqui!</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

