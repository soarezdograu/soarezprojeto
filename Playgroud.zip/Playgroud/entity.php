<?php

class entity extends conexao
{ //extends: herança

    public function list($table)
    {
        $pdo = parent::getInstance();
        $sql = "SELECT * FROM $table order by id ASC";

        $statement = $pdo->query($sql);
        $statement->execute();

        return $statement->fetchALL();
    }

    public function insert($table, $dados)
    {
        $pdo = parent::getInstance();
        $campos = implode(", ", array_keys($dados));
        $valores = ":" . implode(", :", array_keys($dados));

        $sql = "INSERT INTO
            $table($campos) VALUES ($valores)";

        //echo $sql;

        $statement = $pdo->prepare($sql);

        foreach ($dados as $key => $value) {
            $statement->bindValue(":$key", $value, PDO::PARAM_STR);
        }

        // executa o sql no banco
        $statement->execute();
    }

    public function delete($table, $id)
    {
        $pdo = parent::getInstance();

        $sql = "DELETE FROM $table WHERE id = :id";

        //echo $sql;

        $statement = $pdo->prepare($sql);

        $statement->bindValue("id", $id);

        // executa o sql no banco
        $statement->execute();
    }

    public function getinfo($table, $id)
    {
        $pdo = parent::getInstance();

        $sql = "SELECT * FROM $table WHERE id = :id";

        //echo $sql;

        $statement = $pdo->prepare($sql);

        $statement->bindValue("id", $id);

        // executa o sql no banco
        $statement->execute();

        return $statement->fetchALL();
    }

    public function update($table, $dados, $id)
    {
        $pdo = parent::getInstance(); 

        $novos_valores = "";
        foreach($dados as $key => $value){
            $novos_valores .= "$key=:$key, ";
        }

        $novos_valores = substr($novos_valores,0,-2);
        $sql= "UPDATE $table SET $novos_valores WHERE id = :id";
        $statement= $pdo->prepare($sql);


        foreach ($dados as $key => $value) {
            $statement->bindValue(":$key", $value, PDO::PARAM_STR);
        }
       
        $statement->bindValue(":id", $id);

       // echo $sql;

        // executa o sql no banco
        $statement->execute();
    }




    public function login($table, $usuario, $senha)
    {
        $pdo = parent::getInstance();

        $sql = "SELECT * FROM $table WHERE usuario = :usuario and senha= :senha";

        //echo $sql;

        $statement = $pdo->prepare($sql);

        $statement->bindValue("usuario", $usuario);
        $statement->bindValue("senha", $senha);

        // executa o sql no banco
        $statement->execute();

        return $statement->fetchALL();
    }
}

//pagina CRUD= onde tem todas as funções basicas