CREATE DATABASE Loginplaygroud;
USE Loginplaygroud;
-- --------------------------------------------------------

--
-- Estrutura do cadastro
--

DROP TABLE IF EXISTS `Login`;
CREATE TABLE IF NOT EXISTS `Login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL, 
  PRIMARY KEY (`id`) USING BTREE
); 

